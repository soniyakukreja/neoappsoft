import { Component} from "react"

class Class_Context_Api extends Component{

    constructor(){
        super()
        this.state = {

        }
    }

    render(){
        return(
            <div>
                
            </div>
        )
    }
}
