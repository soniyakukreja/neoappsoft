function Pagenotfound() {
    return (
      <div className="card">
          <p><h3>Page Not Found</h3></p>
      </div>	
    );
  }
  
export default Pagenotfound;