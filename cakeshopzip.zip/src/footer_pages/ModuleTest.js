import styles from "./moduletest.module.css";

export default function ModuleTest() {
  return (
    <>
      <h2 class={styles.header}>soniya with module css </h2>
    </>
  );
}
