import { Component} from "react"

class classComponent extends Component{

    constructor(){
        super()
        this.state = {

        }
    }

    render(){
        return(
            <div>
                
            </div>
        )
    }
}